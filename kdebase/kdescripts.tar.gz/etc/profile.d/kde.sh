#!/bin/sh
# KDE additions:
KDEDIR=/opt/kde
PATH=$PATH:$KDEDIR/bin
export KDEDIR PATH
